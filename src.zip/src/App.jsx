import AddTodo from "./components/AddTodo";
import AppName from "./components/AppName";
import "./App.css";
import TodoItems from "./components/Todoitems";
import { useState } from "react";
import WelcomeMassage from "./components/WelcomeMassage";

function App() {
  //const initialTodoitems = [ {name:'Buy milk', dueDate:'04/10/2023'},{name:'go to college',dueDate:'04/10/2023'},{name:'videos',dueDate:'04/10/2023'} ];
  const [todoItemes,setTodoItems] = useState([]);
  const handleNewItem = (itemName, itemDueDate) => {
    console.log(`new item added:${itemName} date:${itemDueDate}`);
    const newTodoItems = [...todoItemes,{name:itemName, dueDate:itemDueDate },];
    setTodoItems(newTodoItems);
  };
  const handleDeleteItem = (todoItemName) => {
    const newTodoItems = todoItemes.filter(item =>item.name !== todoItemName);
    setTodoItems(newTodoItems);

  }

  return (
    <center className="todo-container">
      <AppName />
      <AddTodo onNewItem={handleNewItem} />
      { todoItemes.length === 0 && <WelcomeMassage></WelcomeMassage> }
      <TodoItems todoitems={todoItemes} onDeleteClick={handleDeleteItem} ></TodoItems>            
      
    </center>
  );
}

export default App;
