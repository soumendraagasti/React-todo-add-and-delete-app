import Todoitem from "./Todoitem";
import styles from "./Todoitems.module.css";

const TodoItems = ({todoitems, onDeleteClick}) => {
    return (
        <div className={styles.itemsContainer}>
            {todoitems.map((item) => (<Todoitem key={item.name} todoName={item.name} todoDate={item.dueDate} onDeleteClick={onDeleteClick}></Todoitem> ))}
      </div>
    );
    
};
export default TodoItems;