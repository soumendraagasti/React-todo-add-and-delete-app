import styles from "./WelcomeMassage.module.css";
const WelcomeMassage = () =>{
    return <p className={styles.welcome}>enjoy your day</p>;
};
export default WelcomeMassage;